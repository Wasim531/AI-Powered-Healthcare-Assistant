document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.getElementById("symptomSearch");
    const suggestionBox = document.getElementById("suggestionBox");
    const tagsContainer = document.getElementById("selectedTagsContainer");
    const noTagsPlaceholder = document.getElementById("noTagsPlaceholder");
    const form = document.getElementById("predictionForm");
    const hiddenInput = document.getElementById("symptomsHiddenInput");
    const voiceBtn = document.getElementById("voiceBtn");
    const micIcon = document.getElementById("mic-icon");
    const checkboxes = document.querySelectorAll(".symptom-checkbox");
    
    const formContainer = document.getElementById("prediction-form-container");
    const loaderContainer = document.getElementById("loader-container");
    const loadHeading = document.getElementById("loading-heading");
    const loadSub = document.getElementById("loading-subtext");
    
    let allSymptoms = [];
    let selectedSymptoms = new Set();
    
    // Fetch all symptoms list from API
    fetch("/api/symptoms")
        .then(response => response.json())
        .then(data => {
            allSymptoms = data;
        })
        .catch(err => console.error("Error fetching symptoms:", err));

    // Handle suggestion input filtering
    searchInput.addEventListener("input", function() {
        const query = searchInput.value.toLowerCase().trim();
        if (!query) {
            suggestionBox.classList.add("d-none");
            return;
        }
        
        // Filter out symptoms that are already selected
        const filtered = allSymptoms.filter(s => 
            s.replace(/_/g, " ").toLowerCase().includes(query) && !selectedSymptoms.has(s)
        );
        
        if (filtered.length === 0) {
            suggestionBox.classList.add("d-none");
            return;
        }
        
        suggestionBox.innerHTML = "";
        filtered.forEach(symptom => {
            const div = document.createElement("div");
            div.className = "suggestion-item";
            div.innerText = symptom.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
            div.addEventListener("click", () => {
                addSymptom(symptom);
                searchInput.value = "";
                suggestionBox.classList.add("d-none");
            });
            suggestionBox.appendChild(div);
        });
        suggestionBox.classList.remove("d-none");
    });

    // Close suggestions on outside click
    document.addEventListener("click", function(e) {
        if (e.target !== searchInput && e.target !== suggestionBox) {
            suggestionBox.classList.add("d-none");
        }
    });

    // Add symptom tag
    function addSymptom(symptom) {
        if (selectedSymptoms.has(symptom)) return;
        selectedSymptoms.add(symptom);
        updateTagsUI();
        
        // Sync checkboxes if open
        const chk = document.getElementById(`chk-${symptom}`);
        if (chk) chk.checked = true;
    }

    // Remove symptom tag
    function removeSymptom(symptom) {
        selectedSymptoms.delete(symptom);
        updateTagsUI();
        
        // Sync checkboxes
        const chk = document.getElementById(`chk-${symptom}`);
        if (chk) chk.checked = false;
    }

    // Update the tag list display
    function updateTagsUI() {
        // Clear except placeholder
        tagsContainer.innerHTML = "";
        
        if (selectedSymptoms.size === 0) {
            tagsContainer.appendChild(noTagsPlaceholder);
            return;
        }
        
        selectedSymptoms.forEach(symptom => {
            const span = document.createElement("span");
            span.className = "symptom-tag";
            span.innerHTML = `
                ${symptom.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                <i class="fa-solid fa-xmark" data-symptom="${symptom}"></i>
            `;
            
            span.querySelector("i").addEventListener("click", function() {
                removeSymptom(symptom);
            });
            
            tagsContainer.appendChild(span);
        });
    }

    // Checkbox synchronization
    checkboxes.forEach(chk => {
        chk.addEventListener("change", function() {
            if (this.checked) {
                addSymptom(this.value);
            } else {
                removeSymptom(this.value);
            }
        });
    });

    // Voice recognition setup (Web Speech API)
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;
        
        let isListening = false;
        
        voiceBtn.addEventListener("click", function() {
            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        });
        
        recognition.onstart = function() {
            isListening = true;
            micIcon.className = "fa-solid fa-microphone-lines text-danger animate-pulse";
            searchInput.placeholder = "Listening for symptoms...";
        };
        
        recognition.onend = function() {
            isListening = false;
            micIcon.className = "fa-solid fa-microphone";
            searchInput.placeholder = "Type a symptom (e.g. fever, headache)...";
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript.toLowerCase();
            console.log("Transcribed speech: ", transcript);
            
            // Map spoken terms to known symptoms list
            let matchedAny = false;
            allSymptoms.forEach(symptom => {
                const readable = symptom.replace(/_/g, " ");
                // Simple token keyword detection or substring match
                if (transcript.includes(readable) || transcript.includes(symptom)) {
                    addSymptom(symptom);
                    matchedAny = true;
                }
            });
            
            // Fallback: match parts of words (e.g. sore throat, runny nose)
            if (!matchedAny) {
                const words = transcript.split(/\s+/);
                words.forEach(word => {
                    if (word.length > 3) {
                        allSymptoms.forEach(symptom => {
                            if (symptom.includes(word) && !selectedSymptoms.has(symptom)) {
                                addSymptom(symptom);
                            }
                        });
                    }
                });
            }
        };
        
        recognition.onerror = function(event) {
            console.error("Speech recognition error:", event.error);
        };
    } else {
        voiceBtn.classList.add("d-none"); // Hide if browser not supported
    }

    // Form Submission with Loading Screen Animation
    form.addEventListener("submit", function(e) {
        if (selectedSymptoms.size === 0) {
            e.preventDefault();
            alert("Please select at least one symptom before running diagnostics.");
            return;
        }
        
        e.preventDefault();
        
        // Populate hidden input
        hiddenInput.value = Array.from(selectedSymptoms).join(",");
        
        // Show loading screen, hide form
        formContainer.style.display = "none";
        loaderContainer.style.display = "flex";
        
        // Cycle loading messages for AI feel
        const steps = [
            { heading: "Ingesting Symptomatology", sub: "Aggregating clinical features map..." },
            { heading: "Consulting Random Forest Core", sub: "Calculating tree probabilities over 15 vectors..." },
            { heading: "Extracting Remedial Data", sub: "Compiling precautions, diet, and treatments..." }
        ];
        
        let index = 0;
        const interval = setInterval(() => {
            if (index < steps.length) {
                loadHeading.innerText = steps[index].heading;
                loadSub.innerText = steps[index].sub;
                index++;
            } else {
                clearInterval(interval);
                form.submit(); // Submit actual form to endpoint
            }
        }, 900);
    });
});
