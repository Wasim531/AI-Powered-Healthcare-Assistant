document.addEventListener("DOMContentLoaded", function() {
    const chatForm = document.getElementById("chatForm");
    const chatInput = document.getElementById("chatInput");
    const chatMessages = document.getElementById("chatMessages");
    const chatVoiceBtn = document.getElementById("chatVoiceBtn");
    const chatMicIcon = document.getElementById("chat-mic-icon");

    // Add message bubble
    function appendMessage(text, isUser = false, isHtml = false) {
        const bubble = document.createElement("div");
        bubble.className = `chat-bubble ${isUser ? 'user' : 'bot'}`;
        if (isHtml) {
            bubble.innerHTML = text;
        } else {
            bubble.innerText = text;
        }
        chatMessages.appendChild(bubble);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Add typing indicator
    function showTypingIndicator() {
        const div = document.createElement("div");
        div.className = "chat-bubble bot typing-indicator-wrapper";
        div.id = "typingIndicator";
        div.innerHTML = `
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function removeTypingIndicator() {
        const indicator = document.getElementById("typingIndicator");
        if (indicator) indicator.remove();
    }

    // Handle Form Submit
    chatForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const message = chatInput.value.trim();
        if (!message) return;

        appendMessage(message, true);
        chatInput.value = "";
        
        showTypingIndicator();

        // Send to API
        fetch("/api/chatbot-chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            removeTypingIndicator();
            if (data.error) {
                appendMessage("I ran into an error analyzing your request. Please try again.");
            } else {
                appendMessage(data.response, false, true);
            }
        })
        .catch(err => {
            removeTypingIndicator();
            console.error("Chatbot API Error:", err);
            appendMessage("I couldn't reach the diagnostic server. Please verify your connection.");
        });
    });

    // Voice recognition for chatbot
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        
        let isListening = false;
        
        chatVoiceBtn.addEventListener("click", function() {
            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        });
        
        recognition.onstart = function() {
            isListening = true;
            chatMicIcon.className = "fa-solid fa-microphone-lines text-danger animate-pulse";
            chatInput.placeholder = "Listening...";
        };
        
        recognition.onend = function() {
            isListening = false;
            chatMicIcon.className = "fa-solid fa-microphone";
            chatInput.placeholder = "Describe symptoms in your own words...";
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            chatInput.value = transcript;
        };
        
        recognition.onerror = function(event) {
            console.error("Speech recognition error:", event.error);
        };
    } else {
        chatVoiceBtn.classList.add("d-none");
    }
});
