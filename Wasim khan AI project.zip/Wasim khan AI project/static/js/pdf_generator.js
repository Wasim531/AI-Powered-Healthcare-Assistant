document.addEventListener("DOMContentLoaded", function() {
    const downloadBtn = document.getElementById("downloadPdfBtn");
    
    if (downloadBtn) {
        downloadBtn.addEventListener("click", function() {
            const element = document.getElementById("printable-report");
            
            // Temporary visual updates for printing if necessary (e.g. padding adjustments)
            const opt = {
                margin:       10,
                filename:     `AuraHealth_Report_${Date.now()}.pdf`,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { 
                    scale: 2, 
                    useCORS: true,
                    backgroundColor: '#090b0f', // retain dark mode premium background
                    logging: false
                },
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            // Add a loading text on the button
            const originalContent = downloadBtn.innerHTML;
            downloadBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin me-2"></i>Compiling PDF...`;
            downloadBtn.disabled = true;
            
            // Generate PDF
            html2pdf().set(opt).from(element).save()
                .then(() => {
                    downloadBtn.innerHTML = originalContent;
                    downloadBtn.disabled = false;
                })
                .catch(err => {
                    console.error("PDF generation failed:", err);
                    downloadBtn.innerHTML = originalContent;
                    downloadBtn.disabled = false;
                    alert("Could not compile report PDF. Please try again or print the page directly.");
                });
        });
    }
});
