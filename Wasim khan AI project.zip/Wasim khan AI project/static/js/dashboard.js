document.addEventListener("DOMContentLoaded", function() {
    // 1. Disease Distribution Chart (Doughnut)
    const distCanvas = document.getElementById("diseaseDistributionChart");
    if (distCanvas && window.diseaseLabels && window.diseaseCounts) {
        new Chart(distCanvas, {
            type: 'doughnut',
            data: {
                labels: window.diseaseLabels,
                datasets: [{
                    data: window.diseaseCounts,
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.75)', // Indigo
                        'rgba(0, 242, 254, 0.75)',  // Cyan
                        'rgba(168, 85, 247, 0.75)', // Purple
                        'rgba(16, 185, 129, 0.75)', // Green
                        'rgba(245, 158, 11, 0.75)', // Orange
                        'rgba(239, 68, 68, 0.75)',  // Red
                        'rgba(236, 72, 153, 0.75)', // Pink
                        'rgba(6, 182, 212, 0.75)'   // Teal
                    ],
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    borderWidth: 1.5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: '#94a3b8',
                            font: {
                                family: "'Outfit', sans-serif",
                                size: 12
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. Prediction Trends Over Time (Line Chart)
    const trendCanvas = document.getElementById("predictionFrequencyChart");
    if (trendCanvas && window.trendLabels && window.trendCounts) {
        new Chart(trendCanvas, {
            type: 'line',
            data: {
                labels: window.trendLabels,
                datasets: [{
                    label: 'Simulations Run',
                    data: window.trendCounts,
                    borderColor: '#00f2fe',
                    backgroundColor: 'rgba(0, 242, 254, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#6366f1',
                    pointBorderColor: '#fff',
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.05)'
                        },
                        ticks: {
                            color: '#94a3b8',
                            font: {
                                family: "'Outfit', sans-serif"
                            }
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.05)'
                        },
                        ticks: {
                            color: '#94a3b8',
                            stepSize: 1,
                            font: {
                                family: "'Outfit', sans-serif"
                            }
                        }
                    }
                }
            }
        });
    }
});
