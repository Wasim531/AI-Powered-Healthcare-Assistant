import unittest
import os
import tempfile
import json
from app import app, db, User, Prediction

class AuraHealthTestCase(unittest.TestCase):
    def setUp(self):
        # Configure app for testing
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        
        # Use an in-memory SQLite database for testing isolation
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        
        self.app = app.test_client()
        
        with app.app_context():
            db.create_all()
            
            # Seed a test user
            hashed_pw = "scrypt:32768:8:1$testpbkdf2" # Mock hash placeholder
            self.test_user = User(
                username="tester",
                email="tester@test.com",
                password_hash=hashed_pw,
                is_admin=False
            )
            db.session.add(self.test_user)
            db.session.commit()
            
            # Save ID for testing
            self.test_user_id = self.test_user.id

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_homepage_renders(self):
        """Test that the homepage is reachable and loads HTML."""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'AuraHealth', response.data)

    def test_dashboard_login_restriction(self):
        """Test that unauthorized users are redirected to login when visiting the dashboard."""
        response = self.app.get('/dashboard', follow_redirects=True)
        # Should redirect to login
        self.assertIn(b'Please log in to access this page.', response.data)

    def test_registration(self):
        """Test that user registration works with unique credentials."""
        response = self.app.post('/register', data={
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        }, follow_redirects=True)
        self.assertIn(b'Registration successful. Please log in.', response.data)

    def test_registration_password_mismatch(self):
        """Test registration validation when password confirmation fails."""
        response = self.app.post('/register', data={
            'username': 'mismatch',
            'email': 'mismatch@example.com',
            'password': 'password123',
            'confirm_password': 'password321'
        }, follow_redirects=True)
        self.assertIn(b'Passwords do not match.', response.data)

    def test_api_symptoms(self):
        """Test symptom autocomplete options list endpoint."""
        response = self.app.get('/api/symptoms')
        self.assertEqual(response.status_code, 200)
        # Should return a JSON array
        data = json.loads(response.data.decode('utf-8'))
        self.assertIsInstance(data, list)

    def test_chatbot_fallback_nlp(self):
        """Test chatbot response when no medical keywords are passed."""
        response = self.app.post('/api/chatbot-chat', 
                                 data=json.dumps({'message': 'Hello, how is the weather today?'}),
                                 content_type='application/json')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode('utf-8'))
        self.assertIn('couldn\'t identify any medical symptoms', data['response'].lower())

if __name__ == '__main__':
    unittest.main()
