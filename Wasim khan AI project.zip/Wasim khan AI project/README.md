# AuraHealth AI - Disease Prediction Web Application

AuraHealth AI is a production-ready, full-stack medical prediction simulator. It leverages a trained Random Forest machine learning model to compute disease matching probabilities from symptomatology, paired with a glassmorphic dashboard, an NLP chatbot, voice speech-to-text dictation, and client-side PDF reporting tools.

---

## 🌟 Key Features

1. **Intelligent Prediction Engine**: Simulates diagnostic assessments across **15 conditions** using **28 binary symptoms** via a trained `RandomForestClassifier`.
2. **Symptom Desk Input**: Type symptoms with live auto-suggestions or **speak into your microphone** using browser-native Web Speech API speech-to-text.
3. **Conversational Virtual Assistant**: Chat with the WhatsApp-style AI. It runs a local keyword NLP parser, detects symptoms from your message, and replies with ML predictions.
4. **Health Analytics Dashboard**: Built-in statistics cards showing aggregate metric logs alongside **Chart.js** canvases (doughnut distribution and timeline trend lines).
5. **PDF Report Downloader**: Export a styled, high-fidelity A4 clinical summary sheet in one click using client-side `html2pdf.js`.
6. **Robust Auth Systems**: Register, login, and session persistence using securely hashed passwords with Flask.
7. **Aggregated Admin Center**: Pre-seeded admin portal (`/admin`) for inspecting user credentials, auditing predictions, and managing user roles.

---

## 📁 Directory Structure

```
/wasim-khan-ai-project
│
├── ml/
│   ├── generate_dataset.py     # Script to generate realistic symptoms-disease dataset
│   ├── train_model.py          # Script to train and save the Random Forest model
│   ├── symptoms_disease.csv    # Generated CSV dataset
│   ├── disease_predictor.pkl   # Trained Random Forest classifier binary
│   ├── symptom_features.json   # JSON mapping of symptom feature indices
│   └── disease_info.json       # Precautions, diets, and remedies mapping
│
├── static/
│   ├── css/
│   │   └── style.css           # Premium glassmorphic styling
│   └── js/
│       ├── predict.js          # Speech recognition & autocomplete search
│       ├── dashboard.js        # Chart.js visualization logic
│       ├── chatbot.js          # AI Chatbot NLP request & bubble renderers
│       └── pdf_generator.js    # Client-side PDF generator using html2pdf
│
├── templates/
│   ├── base.html               # Master layout containing navbar, footer, and CDNs
│   ├── home.html               # Sleek marketing homepage with call-to-actions
│   ├── login.html              # Secure credentials login form
│   ├── register.html           # Secure credentials registration form
│   ├── dashboard.html          # Health metrics dashboard with charts
│   ├── predict.html            # Symptom Checklist & tag generator input
│   ├── result.html             # Detailed disease prediction & remedies page
│   ├── chatbot.html            # Live AI assistant chatbot page
│   └── admin.html              # Admin statistics and records viewer
│
├── app.py                      # Flask server, route controllers, and API endpoints
├── database.py                 # SQLite database models (User, Prediction)
├── requirements.txt            # Python dependencies list
├── README.md                   # Comprehensive setup and deployment manual
└── run_app.bat                 # One-click startup script for local Windows run
```

---

## 🚀 Local Installation & Setup

Follow these steps to launch the app on your local machine:

### 1. Prerequisites
Ensure you have **Python 3.8+** installed. Make sure to tick the option to **Add Python to system PATH** during installation.

### 2. Dependency Installation
Install the required packages. Open your terminal in the project root directory and run:
```bash
py -m pip install -r requirements.txt
```
*(On macOS/Linux, replace `py` with `python3` or `pip3 install -r requirements.txt`)*

### 3. Generate Dataset & Train ML Model
Before running the server, generate the synthetic training records and train the classifier by running:
```bash
py ml/generate_dataset.py
py ml/train_model.py
```
This compiles `ml/symptoms_disease.csv` and serialized model binaries `ml/disease_predictor.pkl` + `ml/symptom_features.json` to configure prediction alignments.

### 4. Running the Web Application
Launch the Flask development server:
```bash
py app.py
```
Open your browser and navigate to: **`http://127.0.0.1:5000`**

### Windows One-Click Execution
For convenience on Windows, double-click **`run_app.bat`**. It will automatically scan for missing dataset/model files, train the model if necessary, and boot the server in a new window.

---

## 🔒 Pre-seeded Administrative Credentials
During initial database migration, a default administrator account is seeded for testing:
- **Username**: `admin`
- **Password**: `adminpassword123`

Log in with this account to access the **Admin Control Panel** in the top navbar and manage all logs.

---

## 🧪 Running Automated Tests
The suite checks database isolation, authentication routing, redirects, and NLP chatbot responses:
```bash
py -m unittest test_app.py
```

---

## ☁️ Deployment Guide

### Deploying to Render
1. Create a free account at [Render](https://render.com/).
2. Push your codebase to a **GitHub repository** (public or private).
3. On Render, click **New +** and select **Web Service**.
4. Connect your GitHub repository.
5. Configure the service settings:
   - **Environment**: `Python`
   - **Build Command**: `pip install -r requirements.txt && python ml/generate_dataset.py && python ml/train_model.py` (This builds the ML classifier on build)
   - **Start Command**: `gunicorn app:app`
6. Click **Deploy Web Service**. Render will install dependencies, compile the model, and launch the service.

### Deploying to Railway
1. Create a free account at [Railway](https://railway.app/).
2. Select **New Project** -> **Deploy from GitHub repo**.
3. Choose your repository.
4. Under **Variables**, add a custom variable (optional):
   - `SECRET_KEY`: `your-custom-production-key`
5. Railway automatically detects `requirements.txt` and compiles a Python environment. The database `healthcare.db` will be initialized automatically in the container directory.
6. Under Settings, set the **Start Command**:
   - `python ml/generate_dataset.py && python ml/train_model.py && gunicorn app:app`

---

## 🛠️ Future Improvements
- **Clinical Database Integration**: Hook up prediction inputs directly to EMBL-EBI Ontology Lookup Services or PubMed scientific paper databases to extract citations.
- **Android App wrapping**: Package this web application into a native Android application wrapper using **Capacitor WebView** or **Apache Cordova** pointing to your deployed API server endpoint.
