"""
Cache Manager Module
Handles caching strategies for performance optimization
"""

import json
import hashlib
import logging
from datetime import datetime, timedelta
from functools import lru_cache, wraps
from collections import OrderedDict

logger = logging.getLogger(__name__)

class CacheManager:
    """In-memory cache manager with TTL support."""
    
    def __init__(self, max_size=1000, default_ttl_seconds=3600):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.default_ttl = default_ttl_seconds
        self.stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0
        }
    
    def get(self, key):
        """
        Get value from cache.
        
        Args:
            key (str): Cache key
            
        Returns:
            Value if found and not expired, None otherwise
        """
        if key not in self.cache:
            self.stats['misses'] += 1
            return None
        
        value, expires_at = self.cache[key]
        
        if datetime.utcnow() > expires_at:
            del self.cache[key]
            self.stats['misses'] += 1
            return None
        
        self.stats['hits'] += 1
        # Move to end (LRU)
        self.cache.move_to_end(key)
        return value
    
    def set(self, key, value, ttl_seconds=None):
        """
        Set value in cache.
        
        Args:
            key (str): Cache key
            value: Value to cache
            ttl_seconds (int, optional): Time to live in seconds
        """
        if ttl_seconds is None:
            ttl_seconds = self.default_ttl
        
        expires_at = datetime.utcnow() + timedelta(seconds=ttl_seconds)
        
        # Remove oldest item if cache is full
        if len(self.cache) >= self.max_size:
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
            self.stats['evictions'] += 1
        
        self.cache[key] = (value, expires_at)
        self.cache.move_to_end(key)
        
        logger.debug(f"Cached: {key} (TTL: {ttl_seconds}s)")
    
    def delete(self, key):
        """Delete key from cache."""
        if key in self.cache:
            del self.cache[key]
            logger.debug(f"Deleted from cache: {key}")
    
    def clear(self):
        """Clear entire cache."""
        self.cache.clear()
        logger.info("Cache cleared")
    
    def clean_expired(self):
        """Remove expired entries."""
        now = datetime.utcnow()
        expired_keys = [
            key for key, (_, expires_at) in self.cache.items()
            if now > expires_at
        ]
        
        for key in expired_keys:
            del self.cache[key]
        
        if expired_keys:
            logger.debug(f"Cleaned {len(expired_keys)} expired cache entries")
        
        return len(expired_keys)
    
    def get_stats(self):
        """Get cache statistics."""
        total = self.stats['hits'] + self.stats['misses']
        hit_rate = (self.stats['hits'] / total * 100) if total > 0 else 0
        
        return {
            'size': len(self.cache),
            'max_size': self.max_size,
            'hits': self.stats['hits'],
            'misses': self.stats['misses'],
            'hit_rate': f"{hit_rate:.2f}%",
            'evictions': self.stats['evictions']
        }
    
    def set_key_pattern(self, pattern, value, ttl_seconds=None):
        """Set multiple keys matching a pattern."""
        self.set(pattern, value, ttl_seconds)
    
    def invalidate_pattern(self, pattern):
        """Invalidate all keys matching pattern."""
        keys_to_delete = [k for k in self.cache.keys() if pattern in k]
        for key in keys_to_delete:
            self.delete(key)
        return len(keys_to_delete)


class DatabaseQueryCache:
    """Cache layer for database queries."""
    
    def __init__(self, cache_manager):
        self.cache = cache_manager
    
    def cache_key(self, prefix, *args, **kwargs):
        """Generate cache key from function arguments."""
        key_data = f"{prefix}:{str(args)}:{str(sorted(kwargs.items()))}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def get_user_predictions(self, db, user_id, cache_ttl=300):
        """
        Get user predictions with caching.
        
        Args:
            db: Database instance
            user_id (int): User ID
            cache_ttl (int): Cache TTL in seconds
            
        Returns:
            list: User predictions
        """
        from database import Prediction
        
        cache_key = f"user_predictions:{user_id}"
        cached = self.cache.get(cache_key)
        
        if cached is not None:
            logger.debug(f"Cache hit: {cache_key}")
            return cached
        
        predictions = Prediction.query.filter_by(user_id=user_id)\
            .order_by(Prediction.created_at.desc()).all()
        
        self.cache.set(cache_key, predictions, cache_ttl)
        return predictions
    
    def get_disease_info_cached(self, disease_info_dict, disease_name, cache_ttl=3600):
        """
        Get disease info with caching.
        
        Args:
            disease_info_dict (dict): Disease info dictionary
            disease_name (str): Disease name
            cache_ttl (int): Cache TTL in seconds
            
        Returns:
            dict: Disease information
        """
        cache_key = f"disease_info:{disease_name}"
        cached = self.cache.get(cache_key)
        
        if cached is not None:
            logger.debug(f"Cache hit: {cache_key}")
            return cached
        
        info = disease_info_dict.get(disease_name, {})
        self.cache.set(cache_key, info, cache_ttl)
        return info
    
    def invalidate_user_cache(self, user_id):
        """Invalidate all caches related to a user."""
        invalidated = self.cache.invalidate_pattern(f"user_{user_id}")
        logger.info(f"Invalidated {invalidated} cache entries for user {user_id}")
    
    def get_dashboard_stats(self, db, user_id, cache_ttl=600):
        """
        Get cached dashboard statistics.
        
        Args:
            db: Database instance
            user_id (int): User ID
            cache_ttl (int): Cache TTL in seconds
            
        Returns:
            dict: Dashboard stats
        """
        from database import Prediction
        
        cache_key = f"dashboard_stats:{user_id}"
        cached = self.cache.get(cache_key)
        
        if cached is not None:
            return cached
        
        predictions = Prediction.query.filter_by(user_id=user_id)\
            .order_by(Prediction.created_at.desc()).all()
        
        disease_counts = {}
        for p in predictions:
            disease_counts[p.disease] = disease_counts.get(p.disease, 0) + 1
        
        stats = {
            'predictions': predictions,
            'total_predictions': len(predictions),
            'common_disease': max(disease_counts, key=disease_counts.get) if disease_counts else None,
            'disease_distribution': disease_counts,
            'last_prediction': predictions[0].created_at if predictions else None
        }
        
        self.cache.set(cache_key, stats, cache_ttl)
        return stats


class CachedQueryOptimizer:
    """Optimize database queries with caching and batching."""
    
    def __init__(self, cache_manager):
        self.cache = cache_manager
    
    def batch_get_predictions(self, db, prediction_ids, cache_ttl=300):
        """
        Get multiple predictions efficiently.
        
        Args:
            db: Database instance
            prediction_ids (list): List of prediction IDs
            cache_ttl (int): Cache TTL
            
        Returns:
            dict: Predictions by ID
        """
        from database import Prediction
        
        results = {}
        missing_ids = []
        
        # Check cache first
        for pred_id in prediction_ids:
            cache_key = f"prediction:{pred_id}"
            cached = self.cache.get(cache_key)
            if cached:
                results[pred_id] = cached
            else:
                missing_ids.append(pred_id)
        
        # Query missing
        if missing_ids:
            predictions = Prediction.query.filter(
                Prediction.id.in_(missing_ids)
            ).all()
            
            for pred in predictions:
                cache_key = f"prediction:{pred.id}"
                self.cache.set(cache_key, pred, cache_ttl)
                results[pred.id] = pred
        
        return results
    
    def optimize_join_query(self, db, user_id, cache_ttl=300):
        """
        Optimized query with joins and caching.
        
        Args:
            db: Database instance
            user_id (int): User ID
            cache_ttl (int): Cache TTL
            
        Returns:
            list: User data with predictions and doctors
        """
        from database import User, Prediction
        
        cache_key = f"user_with_predictions:{user_id}"
        cached = self.cache.get(cache_key)
        
        if cached is not None:
            return cached
        
        # Optimized query with eager loading
        user = User.query.options(
            db.joinedload(User.predictions)
        ).filter_by(id=user_id).first()
        
        result = {
            'user': user,
            'predictions': user.predictions if user else [],
            'stats': {
                'total': len(user.predictions) if user else 0,
                'with_doctor': len([p for p in (user.predictions if user else []) if p.selected_doctor])
            }
        }
        
        self.cache.set(cache_key, result, cache_ttl)
        return result


def cache_result(ttl_seconds=300):
    """Decorator to cache function results."""
    cache_mgr = cache_manager
    
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            # Generate cache key
            cache_key = f"{f.__name__}:{str(args)}:{str(sorted(kwargs.items()))}"
            cache_key = hashlib.md5(cache_key.encode()).hexdigest()
            
            # Check cache
            cached = cache_mgr.get(cache_key)
            if cached is not None:
                logger.debug(f"Cache hit for {f.__name__}")
                return cached
            
            # Execute function
            result = f(*args, **kwargs)
            
            # Cache result
            cache_mgr.set(cache_key, result, ttl_seconds)
            return result
        
        return decorated
    return decorator


# Global instances
cache_manager = CacheManager()
db_query_cache = DatabaseQueryCache(cache_manager)
query_optimizer = CachedQueryOptimizer(cache_manager)
