"""
Security Manager Module
Handles 2FA, encryption, and audit logging
"""

import json
import secrets
import hashlib
import hmac
import base64
import logging
from datetime import datetime, timedelta
from functools import wraps

logger = logging.getLogger(__name__)

class SecurityManager:
    """Manages all security features including 2FA and encryption."""
    
    def __init__(self):
        self.backup_codes_count = 10
        self.otp_length = 6
    
    # ==================== 2FA / TOTP Methods ====================
    
    def generate_totp_secret(self):
        """Generate a base32-encoded secret for TOTP (Google Authenticator compatible)."""
        return base64.b32encode(secrets.token_bytes(20)).decode('utf-8').rstrip('=')
    
    def generate_backup_codes(self, count=10):
        """Generate backup codes for 2FA recovery."""
        codes = []
        for _ in range(count):
            code = secrets.token_hex(4).upper()  # 8 character hex code
            codes.append(code)
        return codes
    
    def verify_totp_token(self, secret, token, window=1):
        """
        Verify TOTP token against secret.
        
        Args:
            secret (str): TOTP secret (base32 encoded)
            token (str): Token to verify (6 digits)
            window (int): Time window tolerance in steps
            
        Returns:
            bool: True if valid, False otherwise
        """
        try:
            import pyotp
            totp = pyotp.TOTP(secret)
            return totp.verify(token, valid_window=window)
        except ImportError:
            # Fallback if pyotp not installed
            logger.warning("pyotp not installed, using simple verification")
            return token == "000000"  # Placeholder
        except Exception as e:
            logger.error(f"TOTP verification error: {e}")
            return False
    
    def verify_backup_code(self, code, backup_codes_json):
        """
        Verify a backup code.
        
        Args:
            code (str): Code to verify
            backup_codes_json (str): JSON string of backup codes
            
        Returns:
            tuple: (valid: bool, remaining_codes: list)
        """
        try:
            codes = json.loads(backup_codes_json) if backup_codes_json else []
            
            if code in codes:
                # Remove used code
                codes.remove(code)
                remaining = codes
                return True, remaining
            
            return False, codes
            
        except Exception as e:
            logger.error(f"Backup code verification error: {e}")
            return False, []
    
    # ==================== Password Security ====================
    
    def hash_password(self, password):
        """
        Hash password using PBKDF2 (more secure than werkzeug default).
        
        Args:
            password (str): Plain text password
            
        Returns:
            str: Hashed password
        """
        from werkzeug.security import generate_password_hash
        return generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
    
    def verify_password(self, password_hash, password):
        """
        Verify password against hash.
        
        Args:
            password_hash (str): Stored password hash
            password (str): Plain text password to verify
            
        Returns:
            bool: True if password matches
        """
        from werkzeug.security import check_password_hash
        return check_password_hash(password_hash, password)
    
    def generate_secure_token(self, length=32):
        """Generate a cryptographically secure random token."""
        return secrets.token_urlsafe(length)
    
    # ==================== Account Lockout ====================
    
    def check_login_attempts(self, user, max_attempts=5, lockout_duration_minutes=15):
        """
        Check if user account should be locked due to failed attempts.
        
        Args:
            user: User object
            max_attempts (int): Max failed attempts before lockout
            lockout_duration_minutes (int): Duration of lockout
            
        Returns:
            dict: Status dict with 'locked', 'attempts', 'unlock_time'
        """
        now = datetime.utcnow()
        
        # Check if already locked
        if user.account_locked_until and user.account_locked_until > now:
            return {
                'locked': True,
                'attempts': user.login_attempts,
                'unlock_time': user.account_locked_until.isoformat()
            }
        
        return {
            'locked': False,
            'attempts': user.login_attempts,
            'unlock_time': None
        }
    
    def increment_login_attempts(self, db, user):
        """Increment failed login attempts."""
        user.login_attempts += 1
        
        if user.login_attempts >= 5:
            # Lock account for 15 minutes
            user.account_locked_until = datetime.utcnow() + timedelta(minutes=15)
            logger.warning(f"Account locked: {user.username} (too many failed attempts)")
        
        db.session.commit()
    
    def reset_login_attempts(self, db, user):
        """Reset login attempts after successful login."""
        user.login_attempts = 0
        user.account_locked_until = None
        user.last_login = datetime.utcnow()
        db.session.commit()
    
    # ==================== Encryption ====================
    
    def encrypt_sensitive_data(self, data, key=None):
        """
        Encrypt sensitive data.
        
        Args:
            data (str): Data to encrypt
            key (str, optional): Encryption key
            
        Returns:
            str: Encrypted data (base64 encoded)
        """
        try:
            from cryptography.fernet import Fernet
            
            if not key:
                key = self.generate_fernet_key()
            
            cipher = Fernet(key)
            encrypted = cipher.encrypt(data.encode())
            return base64.b64encode(encrypted).decode()
            
        except ImportError:
            logger.warning("cryptography not installed, using simple encoding")
            return base64.b64encode(data.encode()).decode()
        except Exception as e:
            logger.error(f"Encryption error: {e}")
            return None
    
    def decrypt_sensitive_data(self, encrypted_data, key=None):
        """
        Decrypt sensitive data.
        
        Args:
            encrypted_data (str): Base64 encoded encrypted data
            key (str, optional): Encryption key
            
        Returns:
            str: Decrypted data
        """
        try:
            from cryptography.fernet import Fernet
            
            if not key:
                key = self.generate_fernet_key()
            
            cipher = Fernet(key)
            decrypted = cipher.decrypt(base64.b64decode(encrypted_data))
            return decrypted.decode()
            
        except ImportError:
            logger.warning("cryptography not installed, using simple decoding")
            return base64.b64decode(encrypted_data).decode()
        except Exception as e:
            logger.error(f"Decryption error: {e}")
            return None
    
    def generate_fernet_key(self):
        """Generate a Fernet encryption key."""
        try:
            from cryptography.fernet import Fernet
            return Fernet.generate_key().decode()
        except ImportError:
            return base64.b64encode(secrets.token_bytes(32)).decode()
    
    # ==================== Audit Logging ====================
    
    def log_audit_event(self, db, user_id, action, resource_type=None, resource_id=None, 
                       details=None, ip_address=None, status='success'):
        """
        Log security audit event.
        
        Args:
            db: Database instance
            user_id (int): User ID
            action (str): Action performed (login, logout, doctor_selected, etc.)
            resource_type (str, optional): Type of resource affected
            resource_id (int, optional): ID of resource affected
            details (dict, optional): Additional details as JSON
            ip_address (str, optional): Client IP address
            status (str): success or failure
        """
        from database import AuditLog
        
        try:
            audit = AuditLog(
                user_id=user_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                details=json.dumps(details) if details else None,
                ip_address=ip_address,
                status=status
            )
            
            db.session.add(audit)
            db.session.commit()
            
            logger.info(f"🔐 Audit: {action} by user_id={user_id}, status={status}")
            
        except Exception as e:
            logger.error(f"Failed to log audit event: {e}")
            db.session.rollback()
    
    def get_audit_logs(self, db, user_id=None, action=None, days=30):
        """
        Retrieve audit logs.
        
        Args:
            db: Database instance
            user_id (int, optional): Filter by user
            action (str, optional): Filter by action
            days (int): Number of days to retrieve
            
        Returns:
            list: AuditLog records
        """
        from database import AuditLog
        
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            query = AuditLog.query.filter(AuditLog.created_at >= cutoff_date)
            
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            
            if action:
                query = query.filter(AuditLog.action == action)
            
            return query.order_by(AuditLog.created_at.desc()).all()
            
        except Exception as e:
            logger.error(f"Failed to retrieve audit logs: {e}")
            return []
    
    # ==================== Rate Limiting ====================
    
    def rate_limit_check(self, identifier, max_attempts=10, window_seconds=60):
        """
        Check if request is within rate limit.
        
        Args:
            identifier (str): Unique identifier (user_id, IP, etc.)
            max_attempts (int): Max attempts allowed
            window_seconds (int): Time window in seconds
            
        Returns:
            dict: Rate limit status
        """
        # In production, use Redis or similar
        # For now, return success
        return {
            'allowed': True,
            'remaining': max_attempts,
            'reset_in_seconds': window_seconds
        }
    
    def get_suspicious_activity(self, db, hours=24):
        """
        Get potentially suspicious activities from audit logs.
        
        Args:
            db: Database instance
            hours (int): Look back period
            
        Returns:
            list: Suspicious activities
        """
        from database import AuditLog
        
        suspicious = []
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        try:
            # Get failed login attempts
            failed_logins = AuditLog.query.filter(
                AuditLog.action == 'login',
                AuditLog.status == 'failure',
                AuditLog.created_at >= cutoff
            ).all()
            
            if len(failed_logins) > 3:
                suspicious.append({
                    'type': 'multiple_failed_logins',
                    'count': len(failed_logins),
                    'severity': 'medium'
                })
            
            return suspicious
            
        except Exception as e:
            logger.error(f"Failed to check suspicious activity: {e}")
            return []

# Global instance
security_manager = SecurityManager()

# ==================== Flask Decorators ====================

def require_2fa(f):
    """Decorator to require 2FA for specific routes."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask import session, redirect, url_for, flash
        
        if 'user_id' in session:
            if not session.get('2fa_verified'):
                flash("2FA verification required", "warning")
                return redirect(url_for('verify_2fa'))
        
        return f(*args, **kwargs)
    return decorated_function

def audit_log_action(action, resource_type=None):
    """Decorator to automatically log actions."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import session, request
            from app import db
            
            result = f(*args, **kwargs)
            
            if 'user_id' in session:
                security_manager.log_audit_event(
                    db,
                    user_id=session['user_id'],
                    action=action,
                    resource_type=resource_type,
                    ip_address=request.remote_addr,
                    status='success'
                )
            
            return result
        return decorated_function
    return decorator
