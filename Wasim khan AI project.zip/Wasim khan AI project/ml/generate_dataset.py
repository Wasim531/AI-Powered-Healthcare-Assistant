import csv
import random
import os

# Set random seed for reproducibility
random.seed(42)

# Directory setup
os.makedirs("ml", exist_ok=True)

# List of symptoms (28 total features)
symptoms = [
    "fever", "cough", "fatigue", "body_ache", "runny_nose", 
    "sore_throat", "shortness_of_breath", "loss_of_taste_smell", "headache", "dizziness", 
    "nausea", "vomiting", "diarrhea", "abdominal_pain", "skin_rash", 
    "joint_pain", "frequent_urination", "increased_thirst", "blurred_vision", "chest_pain", 
    "chills", "sweating", "sneezing", "heartburn", "burning_urination", 
    "joint_stiffness", "anxiety", "sleep_disturbance"
]

# Disease mapping with conditional probability of symptoms (disease -> symptom -> probability)
disease_profiles = {
    "Common Cold": {
        "runny_nose": 0.90, "sneezing": 0.90, "sore_throat": 0.80, 
        "cough": 0.70, "fatigue": 0.40, "fever": 0.20, "headache": 0.20
    },
    "Influenza": {
        "fever": 0.90, "body_ache": 0.90, "chills": 0.80, 
        "fatigue": 0.90, "cough": 0.75, "headache": 0.70, 
        "sore_throat": 0.50, "sweating": 0.40
    },
    "COVID-19": {
        "fever": 0.85, "cough": 0.85, "fatigue": 0.80, 
        "loss_of_taste_smell": 0.75, "shortness_of_breath": 0.60, 
        "body_ache": 0.50, "sore_throat": 0.40, "headache": 0.40, 
        "chills": 0.35, "diarrhea": 0.20
    },
    "Diabetes": {
        "frequent_urination": 0.95, "increased_thirst": 0.95, 
        "fatigue": 0.70, "blurred_vision": 0.60, "headache": 0.30
    },
    "Hypertension": {
        "headache": 0.65, "dizziness": 0.60, 
        "shortness_of_breath": 0.40, "chest_pain": 0.30, 
        "sleep_disturbance": 0.30
    },
    "Migraine": {
        "headache": 0.98, "nausea": 0.75, "dizziness": 0.50, 
        "sleep_disturbance": 0.60, "fatigue": 0.40
    },
    "Asthma": {
        "shortness_of_breath": 0.95, "cough": 0.75, 
        "chest_pain": 0.55, "fatigue": 0.30
    },
    "Food Poisoning": {
        "nausea": 0.95, "vomiting": 0.90, "diarrhea": 0.90, 
        "abdominal_pain": 0.95, "fever": 0.40, "fatigue": 0.50, 
        "chills": 0.30
    },
    "Allergies": {
        "sneezing": 0.95, "runny_nose": 0.85, 
        "skin_rash": 0.50, "cough": 0.30, "fatigue": 0.30
    },
    "Malaria": {
        "fever": 0.95, "chills": 0.95, "sweating": 0.85, 
        "headache": 0.75, "nausea": 0.60, "body_ache": 0.60, 
        "vomiting": 0.50, "fatigue": 0.70
    },
    "Typhoid": {
        "fever": 0.98, "headache": 0.75, "abdominal_pain": 0.75, 
        "fatigue": 0.80, "diarrhea": 0.60, "nausea": 0.50, 
        "vomiting": 0.40, "skin_rash": 0.30
    },
    "GERD": {
        "heartburn": 0.98, "chest_pain": 0.60, 
        "nausea": 0.45, "cough": 0.30
    },
    "UTI": {
        "burning_urination": 0.98, "frequent_urination": 0.85, 
        "abdominal_pain": 0.50, "fever": 0.30
    },
    "Arthritis": {
        "joint_pain": 0.98, "joint_stiffness": 0.95, 
        "fatigue": 0.50, "sleep_disturbance": 0.35
    },
    "Anxiety": {
        "anxiety": 0.98, "sleep_disturbance": 0.85, 
        "fatigue": 0.65, "sweating": 0.50, "dizziness": 0.45, 
        "shortness_of_breath": 0.30, "chest_pain": 0.25
    }
}

def generate_record(disease):
    """Generates a binary symptom row based on a disease profile."""
    profile = disease_profiles[disease]
    record = {}
    for symptom in symptoms:
        # Default probability of symptom is noise (2%) unless specified in profile
        prob = profile.get(symptom, 0.02)
        record[symptom] = 1 if random.random() < prob else 0
    record["disease"] = disease
    return record

def main():
    dataset_path = os.path.join("ml", "symptoms_disease.csv")
    num_samples_per_disease = 100  # Total 1500 records
    
    with open(dataset_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=symptoms + ["disease"])
        writer.writeheader()
        
        for disease in disease_profiles.keys():
            for _ in range(num_samples_per_disease):
                row = generate_record(disease)
                writer.writerow(row)
                
    print(f"Dataset generated successfully at: {dataset_path} with {num_samples_per_disease * len(disease_profiles)} records.")

if __name__ == "__main__":
    main()
