import pandas as pd
import numpy as np
import pickle
import json
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

def main():
    csv_path = os.path.join("ml", "symptoms_disease.csv")
    model_path = os.path.join("ml", "disease_predictor.pkl")
    features_path = os.path.join("ml", "symptom_features.json")
    
    if not os.path.exists(csv_path):
        print(f"Error: {csv_path} not found. Please run generate_dataset.py first.")
        return

    # Load dataset
    df = pd.read_csv(csv_path)
    
    # Split features and target
    X = df.drop(columns=["disease"])
    y = df["disease"]
    
    features = list(X.columns)
    
    # Save symptom features order to JSON
    with open(features_path, "w", encoding="utf-8") as f:
        json.dump(features, f, indent=4)
    print(f"Saved symptom features list to: {features_path}")
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # Initialize Random Forest Classifier
    # We use a tuned RF model with high probability accuracy
    model = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=12)
    
    # Train model
    model.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print("\n--- Model Training Summary ---")
    print(f"Overall Accuracy: {accuracy * 100:.2f}%")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Save the model to pickle
    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    print(f"Model saved successfully to: {model_path}")

if __name__ == "__main__":
    main()
