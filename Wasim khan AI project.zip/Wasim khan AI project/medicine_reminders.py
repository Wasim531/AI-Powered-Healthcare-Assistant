"""
Medicine Reminders Module
Handles medicine reminder notifications via email and SMS
"""

import json
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functools import lru_cache
import logging

logger = logging.getLogger(__name__)

class MedicineReminderService:
    """Service for managing and sending medicine reminders."""
    
    def __init__(self, smtp_server="smtp.gmail.com", smtp_port=587):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.cache = {}
    
    def send_email_reminder(self, email, user_name, medicines, disease, doctor_name):
        """
        Send medicine reminder via email.
        
        Args:
            email (str): Recipient email address
            user_name (str): User's name
            medicines (list): List of medicine details
            disease (str): Disease name
            doctor_name (str): Prescribed doctor name
            
        Returns:
            tuple: (success: bool, message: str)
        """
        try:
            # HTML Email Template
            html_content = self._generate_email_template(
                user_name, medicines, disease, doctor_name
            )
            
            # Log the reminder (in production, integrate with actual SMTP)
            logger.info(f"📧 Medicine reminder email prepared for {email}")
            
            # For demo/development, just log and return success
            # In production, integrate with SendGrid, Mailgun, or Gmail SMTP
            return True, "Email reminder queued successfully"
            
        except Exception as e:
            logger.error(f"Failed to send email reminder: {e}")
            return False, f"Email error: {str(e)}"
    
    def send_sms_reminder(self, phone_number, user_name, medicines_summary):
        """
        Send medicine reminder via SMS.
        
        Args:
            phone_number (str): Phone number in E.164 format
            user_name (str): User's name
            medicines_summary (str): Short summary of medicines
            
        Returns:
            tuple: (success: bool, message: str)
        """
        try:
            # SMS format - keep it concise (160 chars)
            sms_text = f"Hi {user_name}! 💊 Reminder to take your medicines: {medicines_summary}. Stay healthy!"
            
            # Log the reminder (in production, integrate with Twilio or AWS SNS)
            logger.info(f"📱 SMS reminder prepared for {phone_number}: {sms_text[:50]}...")
            
            # For demo/development, just log and return success
            # In production, integrate with Twilio or AWS SNS
            return True, "SMS reminder queued successfully"
            
        except Exception as e:
            logger.error(f"Failed to send SMS reminder: {e}")
            return False, f"SMS error: {str(e)}"
    
    def create_medicine_reminder(self, db, prediction_id, user_id, disease_info):
        """
        Create medicine reminders from disease information.
        
        Args:
            db: Database instance
            prediction_id (int): Prediction ID
            user_id (int): User ID
            disease_info (dict): Disease information with medicines
            
        Returns:
            list: Created reminder IDs
        """
        from database import MedicineReminder
        
        reminder_ids = []
        
        try:
            medicines = disease_info.get('medicines', [])
            
            for medicine in medicines:
                # Parse medicine info: "Paracetamol 500mg - 3 times daily for 3-5 days"
                parts = medicine.split(' - ')
                medicine_name = parts[0] if parts else medicine
                frequency = parts[1] if len(parts) > 1 else "As prescribed"
                
                reminder = MedicineReminder(
                    prediction_id=prediction_id,
                    user_id=user_id,
                    medicine_name=medicine_name,
                    dosage=medicine_name,
                    frequency=frequency,
                    start_date=datetime.utcnow(),
                    end_date=datetime.utcnow() + timedelta(days=7),
                    reminder_time="09:00",
                    is_active=True
                )
                
                db.session.add(reminder)
                db.session.flush()
                reminder_ids.append(reminder.id)
                
                logger.info(f"✅ Created reminder: {medicine_name} for user {user_id}")
            
            db.session.commit()
            return reminder_ids
            
        except Exception as e:
            logger.error(f"Failed to create medicine reminder: {e}")
            db.session.rollback()
            return []
    
    def get_pending_reminders(self, db, user_id=None):
        """
        Get all pending medicine reminders.
        
        Args:
            db: Database instance
            user_id (int, optional): Filter by specific user
            
        Returns:
            list: Pending MedicineReminder objects
        """
        from database import MedicineReminder
        
        try:
            query = MedicineReminder.query.filter(
                MedicineReminder.is_active == True,
                MedicineReminder.end_date > datetime.utcnow()
            )
            
            if user_id:
                query = query.filter(MedicineReminder.user_id == user_id)
            
            return query.all()
            
        except Exception as e:
            logger.error(f"Failed to get pending reminders: {e}")
            return []
    
    def send_due_reminders(self, db, user_repository):
        """
        Send all due medicine reminders (background job).
        
        Args:
            db: Database instance
            user_repository: Repository for user queries
            
        Returns:
            dict: Summary of sent reminders
        """
        from database import MedicineReminder, User
        
        summary = {
            'email_sent': 0,
            'sms_sent': 0,
            'failed': 0
        }
        
        try:
            now = datetime.utcnow()
            
            # Get reminders that are due
            due_reminders = MedicineReminder.query.filter(
                MedicineReminder.is_active == True,
                MedicineReminder.end_date > now,
                (MedicineReminder.last_reminder_sent == None) |
                (MedicineReminder.last_reminder_sent < (now - timedelta(hours=24)))
            ).all()
            
            for reminder in due_reminders:
                user = User.query.get(reminder.user_id)
                if not user:
                    continue
                
                # Send email if enabled
                if user.medicine_reminder_email:
                    success, msg = self.send_email_reminder(
                        user.email,
                        user.username,
                        [reminder.medicine_name],
                        "Your Diagnosis",
                        "Dr. Specialist"
                    )
                    if success:
                        summary['email_sent'] += 1
                    else:
                        summary['failed'] += 1
                
                # Send SMS if phone is configured
                if user.medicine_reminder_sms:
                    success, msg = self.send_sms_reminder(
                        user.medicine_reminder_sms,
                        user.username,
                        reminder.medicine_name[:30]
                    )
                    if success:
                        summary['sms_sent'] += 1
                    else:
                        summary['failed'] += 1
                
                # Update reminder status
                reminder.last_reminder_sent = now
                reminder.times_reminded += 1
                db.session.add(reminder)
            
            db.session.commit()
            logger.info(f"Reminder batch completed: {summary}")
            return summary
            
        except Exception as e:
            logger.error(f"Failed to send reminders batch: {e}")
            return summary
    
    def _generate_email_template(self, user_name, medicines, disease, doctor_name):
        """Generate HTML email template for medicine reminders."""
        
        medicines_html = "".join([
            f"<li style='margin: 10px 0; font-size: 14px;'>{med}</li>"
            for med in medicines
        ])
        
        html_template = f"""
        <html>
            <head>
                <style>
                    body {{ font-family: 'Segoe UI', Arial, sans-serif; background-color: #f5f5f5; }}
                    .container {{ max-width: 600px; margin: 20px auto; background: white; border-radius: 8px; }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }}
                    .content {{ padding: 30px; }}
                    .medicine-box {{ background: #f0f4ff; border-left: 4px solid #667eea; padding: 15px; margin: 15px 0; }}
                    .footer {{ text-align: center; padding: 20px; color: #999; font-size: 12px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>💊 Medicine Reminder</h1>
                        <p>Your daily medication schedule</p>
                    </div>
                    <div class="content">
                        <p>Hi <strong>{user_name}</strong>,</p>
                        <p>This is your reminder to take your medicines for <strong>{disease}</strong>.</p>
                        
                        <div class="medicine-box">
                            <h3 style="margin-top: 0;">📋 Prescribed Medicines:</h3>
                            <ul style="margin: 0; padding-left: 20px;">
                                {medicines_html}
                            </ul>
                        </div>
                        
                        <p><strong>Doctor:</strong> {doctor_name}</p>
                        
                        <p style="background: #fff3cd; padding: 10px; border-radius: 4px; border-left: 4px solid #ffc107;">
                            ⚠️ <strong>Important:</strong> Always follow your doctor's instructions. 
                            If you experience any side effects, contact your doctor immediately.
                        </p>
                        
                        <p style="margin-top: 30px; font-size: 14px;">
                            Take care of yourself!<br>
                            <strong>AuraHealth AI</strong>
                        </p>
                    </div>
                    <div class="footer">
                        <p>You received this because you have an active medicine schedule in AuraHealth AI.</p>
                        <p><a href="#" style="color: #667eea; text-decoration: none;">Manage Preferences</a></p>
                    </div>
                </div>
            </body>
        </html>
        """
        
        return html_template

# Global instance
reminder_service = MedicineReminderService()
