#!/usr/bin/env python
"""
Database migration script to add new columns for doctor selection feature.
Run this before starting the app after code updates.
"""

import sqlite3
import os
import sys

DB_PATH = os.path.join('instance', 'healthcare.db')

def migrate_database():
    """Add new columns to predictions table if they don't exist."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Check if selected_doctor column exists
        cursor.execute("PRAGMA table_info(predictions)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'selected_doctor' not in columns:
            print("Adding 'selected_doctor' column...")
            cursor.execute("ALTER TABLE predictions ADD COLUMN selected_doctor VARCHAR(150)")
            print("✓ Added 'selected_doctor' column")
        
        if 'follow_up_days' not in columns:
            print("Adding 'follow_up_days' column...")
            cursor.execute("ALTER TABLE predictions ADD COLUMN follow_up_days INTEGER DEFAULT 7")
            print("✓ Added 'follow_up_days' column")
        
        conn.commit()
        conn.close()
        
        print("\n✓ Database migration completed successfully!")
        return True
        
    except Exception as e:
        print(f"✗ Migration failed: {e}", file=sys.stderr)
        return False

if __name__ == '__main__':
    success = migrate_database()
    sys.exit(0 if success else 1)
