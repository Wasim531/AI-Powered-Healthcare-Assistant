#!/usr/bin/env python
"""Quick fix to add the remaining columns"""

import sqlite3

conn = sqlite3.connect("instance/healthcare.db")
cursor = conn.cursor()

# Add updated_at to users
try:
    cursor.execute('ALTER TABLE users ADD COLUMN updated_at DATETIME')
    print("✅ Added updated_at to users")
except:
    print("ℹ️  updated_at already in users")

# Add updated_at to predictions  
try:
    cursor.execute('ALTER TABLE predictions ADD COLUMN updated_at DATETIME')
    print("✅ Added updated_at to predictions")
except:
    print("ℹ️  updated_at already in predictions")

conn.commit()
conn.close()

print("\n✅ Database fixed! Ready to start app.")
