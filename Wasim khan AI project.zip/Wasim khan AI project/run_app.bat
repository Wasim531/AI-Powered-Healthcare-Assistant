@echo off
title AuraHealth AI - Local Startup Desk
echo ===================================================
echo           AuraHealth AI Platform Startup
echo ===================================================
echo.

:: Check for python launcher
where py >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: Python Launcher (py) was not found on your system PATH.
    echo Please make sure Python is installed.
    pause
    exit /b
)

:: Generate Dataset if missing
if not exist "ml\symptoms_disease.csv" (
    echo [1/3] Generating synthetic symptoms-disease CSV...
    py ml\generate_dataset.py
) else (
    echo [1/3] Dataset CSV already exists. Skipping generation.
)

:: Train ML model if binary is missing
if not exist "ml\disease_predictor.pkl" (
    echo [2/3] Training Random Forest model...
    py ml\train_model.py
) else (
    echo [2/3] Trained ML model binary already exists. Skipping training.
)

:: Launch Flask App
echo [3/3] Initializing database and starting AuraHealth server...
echo Access the application locally at: http://localhost:5000
echo.
py app.py

pause
