#!/usr/bin/env python
"""
Fix Migration Script - Adds missing columns to existing tables
"""

import sqlite3
import os
from datetime import datetime

def print_header(message):
    print(f"\n{'='*60}")
    print(f"  {message}")
    print(f"{'='*60}\n")

def migrate_database():
    """Add missing columns to existing tables."""
    try:
        db_path = "instance/healthcare.db"
        
        if not os.path.exists(db_path):
            print("❌ Database file not found!")
            return False
        
        print_header("🔧 FIXING DATABASE SCHEMA")
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get existing columns
        print("📋 Checking existing columns...")
        
        # Check users table columns
        cursor.execute("PRAGMA table_info(users)")
        user_cols = {row[1] for row in cursor.fetchall()}
        print(f"   Users table has {len(user_cols)} columns")
        
        # Check predictions table columns
        cursor.execute("PRAGMA table_info(predictions)")
        pred_cols = {row[1] for row in cursor.fetchall()}
        print(f"   Predictions table has {len(pred_cols)} columns")
        
        # Add missing columns to users table
        print("\n➕ Adding missing columns to users table...")
        
        user_columns_to_add = {
            'two_factor_enabled': 'BOOLEAN DEFAULT 0',
            'two_factor_secret': 'VARCHAR(32)',
            'backup_codes': 'TEXT',
            'last_login': 'DATETIME',
            'login_attempts': 'INTEGER DEFAULT 0',
            'account_locked_until': 'DATETIME',
            'medicine_reminder_enabled': 'BOOLEAN DEFAULT 1',
            'medicine_reminder_email': 'BOOLEAN DEFAULT 1',
            'medicine_reminder_sms': 'VARCHAR(20)',
            'updated_at': 'DATETIME DEFAULT CURRENT_TIMESTAMP'
        }
        
        for col, col_type in user_columns_to_add.items():
            if col not in user_cols:
                try:
                    cursor.execute(f'ALTER TABLE users ADD COLUMN {col} {col_type}')
                    print(f"   ✅ Added: {col}")
                except sqlite3.OperationalError as e:
                    print(f"   ℹ️  {col}: {e}")
        
        # Add missing columns to predictions table
        print("\n➕ Adding missing columns to predictions table...")
        
        pred_columns_to_add = {
            'medicine_reminder_sent': 'BOOLEAN DEFAULT 0',
            'medicine_reminder_date': 'DATETIME',
            'next_reminder_date': 'DATETIME',
            'reminder_count': 'INTEGER DEFAULT 0',
            'updated_at': 'DATETIME DEFAULT CURRENT_TIMESTAMP'
        }
        
        for col, col_type in pred_columns_to_add.items():
            if col not in pred_cols:
                try:
                    cursor.execute(f'ALTER TABLE predictions ADD COLUMN {col} {col_type}')
                    print(f"   ✅ Added: {col}")
                except sqlite3.OperationalError as e:
                    print(f"   ℹ️  {col}: {e}")
        
        # Create new tables if they don't exist
        print("\n📊 Creating new tables (if needed)...")
        
        # medicine_reminders table
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS medicine_reminders (
                    id INTEGER PRIMARY KEY,
                    prediction_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    medicine_name VARCHAR(200),
                    dosage VARCHAR(100),
                    frequency VARCHAR(100),
                    start_date DATETIME,
                    end_date DATETIME,
                    reminder_time VARCHAR(5),
                    is_active BOOLEAN DEFAULT 1,
                    last_reminder_sent DATETIME,
                    times_reminded INTEGER DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (prediction_id) REFERENCES predictions(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            print("   ✅ medicine_reminders table created/verified")
        except Exception as e:
            print(f"   ℹ️  medicine_reminders: {e}")
        
        # audit_logs table
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    action VARCHAR(100),
                    resource_type VARCHAR(50),
                    resource_id INTEGER,
                    details TEXT,
                    ip_address VARCHAR(45),
                    status VARCHAR(20) DEFAULT 'success',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            print("   ✅ audit_logs table created/verified")
        except Exception as e:
            print(f"   ℹ️  audit_logs: {e}")
        
        # appointments table
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS appointments (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    prediction_id INTEGER,
                    doctor_name VARCHAR(150),
                    doctor_specialty VARCHAR(100),
                    appointment_date DATETIME,
                    appointment_time VARCHAR(5),
                    duration_minutes INTEGER DEFAULT 30,
                    status VARCHAR(20) DEFAULT 'scheduled',
                    notes TEXT,
                    reminder_sent BOOLEAN DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id),
                    FOREIGN KEY (prediction_id) REFERENCES predictions(id)
                )
            ''')
            print("   ✅ appointments table created/verified")
        except Exception as e:
            print(f"   ℹ️  appointments: {e}")
        
        conn.commit()
        conn.close()
        
        print_header("✅ MIGRATION COMPLETE")
        
        print("""
DATABASE STATUS:
─────────────────────────────────────────
✅ All columns added to existing tables
✅ All new tables created
✅ Database schema updated
✅ Ready to start application

NEXT STEP:
─────────────────────────────────────────
python app.py

Then visit: http://localhost:5000
        """)
        
        return True
        
    except Exception as e:
        print_header("❌ MIGRATION FAILED")
        print(f"Error: {e}\n")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    import sys
    success = migrate_database()
    sys.exit(0 if success else 1)
