import os
import json
import pickle
import numpy as np
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Import Database Config and Models
from database import db, User, Prediction, MedicineReminder, AuditLog, Appointment

# Import Security and Caching Modules
from security_manager import security_manager, audit_log_action
from medicine_reminders import reminder_service
from cache_manager import cache_manager, db_query_cache, query_optimizer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-aurahealth-key-1234')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthcare.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize DB with App
db.init_app(app)

# Global variables for Machine Learning Core
model = None
symptom_features = []
disease_info = {}

def load_ml_assets():
    """Load model, features list, and recommendations mapping."""
    global model, symptom_features, disease_info
    
    model_path = os.path.join("ml", "disease_predictor.pkl")
    features_path = os.path.join("ml", "symptom_features.json")
    info_path = os.path.join("ml", "disease_info.json")
    
    try:
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                model = pickle.load(f)
            print("ML Model loaded successfully.")
        else:
            print("Warning: disease_predictor.pkl not found. Please train the model.")
            
        if os.path.exists(features_path):
            with open(features_path, "r", encoding="utf-8") as f:
                symptom_features = json.load(f)
            print("Symptom features loaded.")
        
        if os.path.exists(info_path):
            with open(info_path, "r", encoding="utf-8") as f:
                disease_info = json.load(f)
            print("Disease info guidelines loaded.")
            
    except Exception as e:
        print(f"Error loading ML assets: {e}")

# Load assets initially
load_ml_assets()

# --- Decorators for Auth Restricting ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access this page.", "error")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_admin'):
            flash("Administrator rights required.", "error")
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# --- App Context active page tracker ---
@app.context_processor
def inject_active_page():
    return dict(active_page=request.endpoint)

# --- Routes ---

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not username or not email or not password:
            flash("All fields are required.", "error")
            return render_template('register.html')
            
        if password != confirm_password:
            flash("Passwords do not match.", "error")
            return render_template('register.html')
            
        # Check if username or email already registered
        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            flash("Username or Email already registered.", "error")
            return render_template('register.html')
        
        # Use enhanced password hashing
        hashed_pw = security_manager.hash_password(password)
        new_user = User(username=username, email=email, password_hash=hashed_pw)
        
        db.session.add(new_user)
        db.session.commit()
        
        # Log registration
        security_manager.log_audit_event(
            db, new_user.id, 'register', status='success',
            ip_address=request.remote_addr
        )
        
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password')
        
        # Rate limiting check
        rate_limit = security_manager.rate_limit_check(username)
        if not rate_limit['allowed']:
            flash(f"Too many login attempts. Try again later.", "error")
            return redirect(url_for('login'))
        
        user = User.query.filter_by(username=username).first()
        
        # Check account lockout
        if user:
            lockout_status = security_manager.check_login_attempts(user)
            if lockout_status['locked']:
                flash("Account temporarily locked due to failed login attempts. Try again in 15 minutes.", "error")
                security_manager.log_audit_event(
                    db, user.id, 'login', status='failure',
                    details={'reason': 'account_locked'},
                    ip_address=request.remote_addr
                )
                return render_template('login.html')
        
        if user and security_manager.verify_password(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin
            session['2fa_verified'] = False  # Mark 2FA as not verified yet
            
            # Reset login attempts
            security_manager.reset_login_attempts(db, user)
            
            # Log successful login
            security_manager.log_audit_event(
                db, user.id, 'login', status='success',
                ip_address=request.remote_addr
            )
            
            # Check if 2FA is enabled
            if user.two_factor_enabled:
                flash("Please verify your 2FA token to continue.", "info")
                return redirect(url_for('verify_2fa'))
            
            flash("Logged in successfully.", "success")
            return redirect(url_for('dashboard'))
        else:
            # Log failed login
            if user:
                security_manager.increment_login_attempts(db, user)
                security_manager.log_audit_event(
                    db, user.id, 'login', status='failure',
                    details={'reason': 'invalid_password'},
                    ip_address=request.remote_addr
                )
            else:
                security_manager.log_audit_event(
                    db, None, 'login', status='failure',
                    details={'reason': 'user_not_found', 'username': username},
                    ip_address=request.remote_addr
                )
            
            flash("Invalid credentials.", "error")
            
    return render_template('login.html')

@app.route('/verify-2fa', methods=['GET', 'POST'])
@login_required
def verify_2fa():
    """Verify 2FA token."""
    if session.get('2fa_verified'):
        return redirect(url_for('dashboard'))
    
    user = User.query.get(session['user_id'])
    if not user or not user.two_factor_enabled:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        token = request.form.get('token', '').strip()
        use_backup = request.form.get('use_backup', False)
        
        if use_backup:
            # Verify backup code
            valid, remaining_codes = security_manager.verify_backup_code(
                token, user.backup_codes
            )
            if valid:
                user.backup_codes = json.dumps(remaining_codes)
                db.session.commit()
                session['2fa_verified'] = True
                flash("2FA verified using backup code.", "success")
                return redirect(url_for('dashboard'))
            else:
                flash("Invalid backup code.", "error")
        else:
            # Verify TOTP token
            if security_manager.verify_totp_token(user.two_factor_secret, token):
                session['2fa_verified'] = True
                flash("2FA verified successfully.", "success")
                return redirect(url_for('dashboard'))
            else:
                flash("Invalid 2FA token. Please try again.", "error")
    
    return render_template('verify_2fa.html')

@app.route('/setup-2fa', methods=['GET', 'POST'])
@login_required
def setup_2fa():
    """Setup 2FA for user account."""
    user = User.query.get(session['user_id'])
    
    if user.two_factor_enabled:
        flash("2FA is already enabled on your account.", "info")
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        token = request.form.get('token', '').strip()
        
        # Verify token is correct
        if security_manager.verify_totp_token(user.two_factor_secret, token):
            # Generate backup codes
            backup_codes = security_manager.generate_backup_codes(10)
            
            user.two_factor_enabled = True
            user.backup_codes = json.dumps(backup_codes)
            db.session.commit()
            
            security_manager.log_audit_event(
                db, user.id, 'setup_2fa', status='success'
            )
            
            flash("2FA enabled successfully! Save your backup codes in a safe place.", "success")
            return render_template('backup_codes.html', codes=backup_codes)
        else:
            flash("Invalid token. Please try again.", "error")
    
    # Generate new secret for setup
    secret = security_manager.generate_totp_secret()
    session['temp_2fa_secret'] = secret
    
    return render_template('setup_2fa.html', secret=secret)

@app.route('/disable-2fa', methods=['POST'])
@login_required
def disable_2fa():
    """Disable 2FA for user account."""
    user = User.query.get(session['user_id'])
    password = request.form.get('password')
    
    # Verify password
    if not security_manager.verify_password(user.password_hash, password):
        flash("Invalid password.", "error")
        return redirect(url_for('dashboard'))
    
    user.two_factor_enabled = False
    user.two_factor_secret = None
    user.backup_codes = None
    db.session.commit()
    
    security_manager.log_audit_event(
        db, user.id, 'disable_2fa', status='success'
    )
    
    flash("2FA has been disabled.", "success")
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    user_id = session['user_id']
    
    # Get cached dashboard stats
    stats = db_query_cache.get_dashboard_stats(db, user_id, cache_ttl=600)
    
    predictions = stats['predictions'] if 'predictions' in stats else \
        Prediction.query.filter_by(user_id=user_id).order_by(Prediction.created_at.desc()).all()
    
    total_predictions = stats.get('total_predictions', len(predictions))
    common_disease = stats.get('common_disease')
    last_active = predictions[0].created_at.strftime('%Y-%m-%d') if predictions else None
    
    # Prepare Chart.js data
    disease_distribution = stats.get('disease_distribution', {})
    disease_labels = list(disease_distribution.keys())
    disease_counts_list = list(disease_distribution.values())
    
    # Aggregate prediction counts by day
    trend_data = {}
    for p in reversed(predictions):
        date_str = p.created_at.strftime('%m-%d')
        trend_data[date_str] = trend_data.get(date_str, 0) + 1
    
    trend_labels = list(trend_data.keys())
    trend_counts = list(trend_data.values())
    
    return render_template('dashboard.html', 
                           predictions=predictions, 
                           total_predictions=total_predictions, 
                           common_disease=common_disease, 
                           last_active=last_active,
                           disease_labels=disease_labels,
                           disease_counts=disease_counts_list,
                           trend_labels=trend_labels,
                           trend_counts=trend_counts)

@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    global model, symptom_features
    if model is None or not symptom_features:
        load_ml_assets()
        
    if request.method == 'POST':
        symptoms_str = request.form.get('symptoms', '').strip()
        if not symptoms_str:
            flash("No symptoms selected.", "error")
            return redirect(url_for('predict'))
            
        selected = symptoms_str.split(',')
        
        # Prepare feature vector (all zeros, set active symptoms to 1)
        vector = [0] * len(symptom_features)
        for s in selected:
            if s in symptom_features:
                idx = symptom_features.index(s)
                vector[idx] = 1
                
        # Perform machine learning prediction
        try:
            probabilities = model.predict_proba([vector])[0]
            max_idx = np.argmax(probabilities)
            predicted_disease = model.classes_[max_idx]
            probability = float(probabilities[max_idx]) * 100.0
            
            # Save prediction to DB
            new_pred = Prediction(
                user_id=session['user_id'],
                symptoms=symptoms_str,
                disease=predicted_disease,
                probability=probability
            )
            db.session.add(new_pred)
            db.session.commit()
            
            return redirect(url_for('result', pred_id=new_pred.id))
        except Exception as e:
            flash(f"ML Core error during prediction: {e}", "error")
            return redirect(url_for('predict'))
            
    return render_template('predict.html', all_symptoms=symptom_features)

@app.route('/result/<int:pred_id>')
@login_required
def result(pred_id):
    prediction = Prediction.query.get_or_404(pred_id)
    
    # Restrict users to viewing only their own predictions, unless admin
    if prediction.user_id != session['user_id'] and not session.get('is_admin'):
        flash("Unauthorized access to report log.", "error")
        return redirect(url_for('dashboard'))
        
    info = disease_info.get(prediction.disease, {
        "precautions": ["Consult a medical practitioner.", "Rest and hydrate."],
        "diet": {
            "recommend": ["Hydrating fluids", "Balanced whole foods"],
            "avoid": ["Heavy fats", "High sodium foods"]
        },
        "remedies": ["Adequate bed rest.", "Follow standard clinical guidelines."]
    })
    
    return render_template('result.html', prediction=prediction, info=info)

@app.route('/delete-prediction/<int:pred_id>', methods=['POST'])
@login_required
def delete_prediction(pred_id):
    pred = Prediction.query.get_or_404(pred_id)
    if pred.user_id != session['user_id'] and not session.get('is_admin'):
        flash("Unauthorized deletion attempt.", "error")
    else:
        db.session.delete(pred)
        db.session.commit()
        flash("Prediction log deleted.", "success")
    return redirect(url_for('dashboard'))

@app.route('/api/update-doctor-selection/<int:pred_id>', methods=['POST'])
@login_required
def update_doctor_selection(pred_id):
    """Save selected doctor and follow-up days for a prediction."""
    pred = Prediction.query.get_or_404(pred_id)
    
    # Verify authorization
    if pred.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({"success": False, "error": "Unauthorized"}), 403
    
    data = request.get_json() or {}
    doctor = data.get('doctor', '')
    follow_up_days = data.get('follow_up_days', 7)
    
    # Update prediction with doctor selection
    pred.selected_doctor = doctor
    pred.follow_up_days = int(follow_up_days)
    
    # Create medicine reminders from disease info
    disease_info_data = disease_info.get(pred.disease, {})
    reminder_ids = reminder_service.create_medicine_reminder(
        db, pred_id, session['user_id'], disease_info_data
    )
    
    db.session.commit()
    
    # Log the action
    security_manager.log_audit_event(
        db, session['user_id'], 'doctor_selected',
        resource_type='prediction', resource_id=pred_id,
        details={'doctor': doctor, 'follow_up_days': follow_up_days, 'reminders': len(reminder_ids)}
    )
    
    return jsonify({
        "success": True,
        "message": "Doctor selection and medicine reminders saved successfully",
        "reminders_created": len(reminder_ids)
    })

@app.route('/chatbot')
@login_required
def chatbot():
    return render_template('chatbot.html')

# ==================== MEDICINE REMINDERS ROUTES ====================

@app.route('/medicine-reminders')
@login_required
def medicine_reminders():
    """View all medicine reminders for logged-in user."""
    user_id = session['user_id']
    
    # Use cached query
    reminders = db_query_cache.cache.get(f"user_reminders:{user_id}")
    if reminders is None:
        reminders = MedicineReminder.query.filter_by(user_id=user_id).all()
        db_query_cache.cache.set(f"user_reminders:{user_id}", reminders, 300)
    
    return render_template('medicine_reminders.html', reminders=reminders)

@app.route('/api/medicine-reminders/<int:reminder_id>/toggle', methods=['POST'])
@login_required
def toggle_medicine_reminder(reminder_id):
    """Enable/disable a medicine reminder."""
    reminder = MedicineReminder.query.get_or_404(reminder_id)
    
    if reminder.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({"success": False, "error": "Unauthorized"}), 403
    
    reminder.is_active = not reminder.is_active
    db.session.commit()
    
    # Invalidate cache
    db_query_cache.cache.invalidate_pattern(f"user_reminders:{session['user_id']}")
    
    security_manager.log_audit_event(
        db, session['user_id'], 'toggle_reminder',
        resource_type='medicine_reminder', resource_id=reminder_id,
        details={'is_active': reminder.is_active}
    )
    
    return jsonify({"success": True, "is_active": reminder.is_active})

@app.route('/api/medicine-reminders/<int:reminder_id>/delete', methods=['POST'])
@login_required
def delete_medicine_reminder(reminder_id):
    """Delete a medicine reminder."""
    reminder = MedicineReminder.query.get_or_404(reminder_id)
    
    if reminder.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({"success": False, "error": "Unauthorized"}), 403
    
    db.session.delete(reminder)
    db.session.commit()
    
    # Invalidate cache
    db_query_cache.cache.invalidate_pattern(f"user_reminders:{session['user_id']}")
    
    security_manager.log_audit_event(
        db, session['user_id'], 'delete_reminder',
        resource_type='medicine_reminder', resource_id=reminder_id
    )
    
    return jsonify({"success": True})

# ==================== APPOINTMENT ROUTES ====================

@app.route('/appointments')
@login_required
def appointments():
    """View all appointments for logged-in user."""
    user_id = session['user_id']
    appointments = Appointment.query.filter_by(user_id=user_id)\
        .order_by(Appointment.appointment_date.desc()).all()
    
    return render_template('appointments.html', appointments=appointments)

@app.route('/appointments/new', methods=['GET', 'POST'])
@login_required
def create_appointment():
    """Create a new appointment."""
    if request.method == 'POST':
        doctor_name = request.form.get('doctor_name')
        doctor_specialty = request.form.get('doctor_specialty')
        appointment_date = request.form.get('appointment_date')
        appointment_time = request.form.get('appointment_time')
        
        appointment = Appointment(
            user_id=session['user_id'],
            doctor_name=doctor_name,
            doctor_specialty=doctor_specialty,
            appointment_date=datetime.fromisoformat(appointment_date),
            appointment_time=appointment_time,
            status='scheduled'
        )
        
        db.session.add(appointment)
        db.session.commit()
        
        security_manager.log_audit_event(
            db, session['user_id'], 'create_appointment',
            resource_type='appointment', resource_id=appointment.id,
            details={'doctor': doctor_name, 'date': appointment_date}
        )
        
        flash("Appointment scheduled successfully.", "success")
        return redirect(url_for('appointments'))
    
    return render_template('create_appointment.html')

@app.route('/appointments/<int:appointment_id>/cancel', methods=['POST'])
@login_required
def cancel_appointment(appointment_id):
    """Cancel an appointment."""
    appointment = Appointment.query.get_or_404(appointment_id)
    
    if appointment.user_id != session['user_id'] and not session.get('is_admin'):
        flash("Unauthorized", "error")
        return redirect(url_for('appointments'))
    
    appointment.status = 'cancelled'
    db.session.commit()
    
    security_manager.log_audit_event(
        db, session['user_id'], 'cancel_appointment',
        resource_type='appointment', resource_id=appointment_id
    )
    
    flash("Appointment cancelled.", "success")
    return redirect(url_for('appointments'))

# ==================== SECURITY & AUDIT ROUTES ====================

@app.route('/security/audit-logs')
@login_required
def view_audit_logs():
    """View user's own audit logs."""
    user_id = session['user_id']
    logs = security_manager.get_audit_logs(db, user_id=user_id, days=30)
    return render_template('audit_logs.html', logs=logs)

@app.route('/cache-stats')
def cache_stats():
    """View cache statistics (admin only)."""
    if not session.get('is_admin'):
        return redirect(url_for('home'))
    
    stats = cache_manager.get_stats()
    return jsonify(stats)

# --- API Endpoints ---

@app.route('/api/symptoms', methods=['GET'])
def get_symptoms():
    return jsonify(symptom_features)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """REST API endpoint for prediction."""
    global model, symptom_features
    if model is None:
        return jsonify({"error": "ML Model not initialized."}), 500
        
    data = request.get_json() or {}
    symptoms = data.get('symptoms', [])
    
    if not symptoms:
        return jsonify({"error": "No symptoms provided."}), 400
        
    vector = [0] * len(symptom_features)
    for s in symptoms:
        if s in symptom_features:
            idx = symptom_features.index(s)
            vector[idx] = 1
            
    try:
        probabilities = model.predict_proba([vector])[0]
        max_idx = np.argmax(probabilities)
        predicted_disease = model.classes_[max_idx]
        probability = float(probabilities[max_idx]) * 100.0
        
        info = disease_info.get(predicted_disease, {})
        
        return jsonify({
            "disease": predicted_disease,
            "probability": probability,
            "recommendations": info
        })
    except Exception as e:
        return jsonify({"error": f"ML calculation failed: {e}"}), 500

@app.route('/api/chatbot-chat', methods=['POST'])
def chatbot_chat():
    """Chatbot conversational handler with NLP symptom extraction."""
    global model, symptom_features
    if model is None:
        return jsonify({"error": "ML core down"}), 500
        
    data = request.get_json() or {}
    message = data.get('message', '').lower()
    
    # NLP keyword extraction
    detected = []
    for symptom in symptom_features:
        # replace underscores for space searching
        readable = symptom.replace('_', ' ')
        if readable in message or symptom in message:
            detected.append(symptom)
            
    if not detected:
        # Check subwords
        for word in message.split():
            if len(word) > 3:
                for symptom in symptom_features:
                    if word in symptom and symptom not in detected:
                        detected.append(symptom)
                        
    if not detected:
        response_text = (
            "I couldn't identify any medical symptoms in your description. "
            "Could you please specify symptoms like <strong>fever, cough, headache, abdominal pain</strong>, or others?"
        )
        return jsonify({"response": response_text})
        
    # Execute prediction based on NLP symptoms
    vector = [0] * len(symptom_features)
    for s in detected:
        idx = symptom_features.index(s)
        vector[idx] = 1
        
    try:
        probabilities = model.predict_proba([vector])[0]
        max_idx = np.argmax(probabilities)
        disease = model.classes_[max_idx]
        prob = float(probabilities[max_idx]) * 100.0
        
        info = disease_info.get(disease, {})
        precautions = info.get("precautions", ["Rest and hydrate."])
        
        detected_readable = ", ".join([s.replace('_', ' ') for s in detected])
        
        response_text = f"""
            Based on the symptoms you mentioned (<strong>{detected_readable}</strong>):
            <br><br>
            I predict a <strong>{prob:.1f}% probability</strong> of <strong>{disease}</strong>.
            <br><br>
            <strong>Core Precautions:</strong>
            <ul>
                {"".join([f"<li>{p}</li>" for p in precautions[:3]])}
            </ul>
            <br>
            <em>Please log this simulation in your Symptom Desk to view your detailed Diet guidelines and Remedies.</em>
        """
        return jsonify({"response": response_text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- Admin Routes ---

@app.route('/admin')
@admin_required
def admin():
    users = User.query.all()
    predictions = Prediction.query.order_by(Prediction.created_at.desc()).all()
    total_users = len(users)
    total_predictions = len(predictions)
    return render_template('admin.html', users=users, predictions=predictions, total_users=total_users, total_predictions=total_predictions)

@app.route('/admin/toggle-role/<int:user_id>', methods=['POST'])
@admin_required
def admin_toggle_role(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == session.get('user_id'):
        flash("You cannot revoke your own admin rights.", "error")
    else:
        user.is_admin = not user.is_admin
        db.session.commit()
        flash(f"User {user.username} role updated.", "success")
    return redirect(url_for('admin'))

@app.route('/admin/delete-user/<int:user_id>', methods=['POST'])
@admin_required
def admin_delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == session.get('user_id'):
        flash("You cannot delete the current session user.", "error")
    else:
        db.session.delete(user)
        db.session.commit()
        flash(f"User {user.username} has been deleted.", "success")
    return redirect(url_for('admin'))

@app.route('/admin/delete-prediction/<int:pred_id>', methods=['POST'])
@admin_required
def admin_delete_prediction(pred_id):
    pred = Prediction.query.get_or_404(pred_id)
    db.session.delete(pred)
    db.session.commit()
    flash("Prediction log purged.", "success")
    return redirect(url_for('admin'))

# --- DB Initialization and Admin Seeding ---
def seed_admin():
    """Create database and seed admin account if not existing."""
    with app.app_context():
        db.create_all()
        # Seed Admin user
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@aurahealth.ai',
                password_hash=security_manager.hash_password('adminpassword123'),
                is_admin=True
            )
            db.session.add(admin_user)
            db.session.commit()
            print("Database created and admin user seeded (admin/adminpassword123).")
        
        # Log startup
        logger.info("Application initialized and database ready")

if __name__ == '__main__':
    seed_admin()
    
    # Startup message
    print("\n" + "="*60)
    print("🏥 AURAHEALTH AI - ENHANCED VERSION")
    print("="*60)
    print("✅ New Features Enabled:")
    print("   • Medicine Reminders & Notifications")
    print("   • Two-Factor Authentication (2FA)")
    print("   • Database Query Caching")
    print("   • Audit Logging & Security")
    print("   • Appointment Management")
    print("   • Enhanced Password Security")
    print("\n📊 Cache Manager Active")
    print("🔐 Security Manager Active")
    print("💊 Medicine Reminders Active")
    print("\n🚀 Starting on http://0.0.0.0:5000")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
