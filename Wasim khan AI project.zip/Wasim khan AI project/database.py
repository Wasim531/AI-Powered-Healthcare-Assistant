from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import secrets

# Initialize the SQLAlchemy object
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    
    # 2FA & Security Features
    two_factor_enabled = db.Column(db.Boolean, default=False)
    two_factor_secret = db.Column(db.String(32), nullable=True)
    backup_codes = db.Column(db.Text, nullable=True)  # JSON array of backup codes
    last_login = db.Column(db.DateTime, nullable=True)
    login_attempts = db.Column(db.Integer, default=0)
    account_locked_until = db.Column(db.DateTime, nullable=True)
    
    # Medicine Reminders
    medicine_reminder_enabled = db.Column(db.Boolean, default=True)
    medicine_reminder_email = db.Column(db.Boolean, default=True)
    medicine_reminder_sms = db.Column(db.String(20), nullable=True)  # Phone number for SMS
    
    # Audit & Tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<User {self.username}>"

class Prediction(db.Model):
    __tablename__ = 'predictions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    symptoms = db.Column(db.Text, nullable=False)
    disease = db.Column(db.String(100), nullable=False, index=True)
    probability = db.Column(db.Float, nullable=False)
    selected_doctor = db.Column(db.String(150), nullable=True)
    follow_up_days = db.Column(db.Integer, default=7)
    
    # Medicine Reminders
    medicine_reminder_sent = db.Column(db.Boolean, default=False)
    medicine_reminder_date = db.Column(db.DateTime, nullable=True)
    next_reminder_date = db.Column(db.DateTime, nullable=True)
    reminder_count = db.Column(db.Integer, default=0)
    
    # Audit Trail
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('predictions', lazy=True, cascade="all, delete-orphan"))

    def __repr__(self):
        return f"<Prediction {self.disease} ({self.probability}%)>"

class MedicineReminder(db.Model):
    __tablename__ = 'medicine_reminders'
    
    id = db.Column(db.Integer, primary_key=True)
    prediction_id = db.Column(db.Integer, db.ForeignKey('predictions.id', ondelete='CASCADE'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    medicine_name = db.Column(db.String(200), nullable=False)
    dosage = db.Column(db.String(100), nullable=False)
    frequency = db.Column(db.String(100), nullable=False)  # e.g., "3 times daily"
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=True)
    reminder_time = db.Column(db.String(5), default="09:00")  # HH:MM format
    
    # Reminder Status
    is_active = db.Column(db.Boolean, default=True)
    last_reminder_sent = db.Column(db.DateTime, nullable=True)
    times_reminded = db.Column(db.Integer, default=0)
    
    # Tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    prediction = db.relationship('Prediction', backref=db.backref('medicine_reminders', lazy=True, cascade="all, delete-orphan"))
    user = db.relationship('User', backref=db.backref('medicine_reminders', lazy=True))

    def __repr__(self):
        return f"<MedicineReminder {self.medicine_name}>"

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True, index=True)
    action = db.Column(db.String(100), nullable=False, index=True)  # e.g., "login", "doctor_selected", "medicine_set"
    resource_type = db.Column(db.String(50), nullable=True)  # e.g., "prediction", "user"
    resource_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.Text, nullable=True)  # JSON details
    ip_address = db.Column(db.String(45), nullable=True)
    status = db.Column(db.String(20), default="success")  # success, failure
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship('User', backref=db.backref('audit_logs', lazy=True))

    def __repr__(self):
        return f"<AuditLog {self.action}>"

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    prediction_id = db.Column(db.Integer, db.ForeignKey('predictions.id', ondelete='CASCADE'), nullable=True)
    doctor_name = db.Column(db.String(150), nullable=False)
    doctor_specialty = db.Column(db.String(100), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False, index=True)
    appointment_time = db.Column(db.String(5), nullable=False)  # HH:MM format
    duration_minutes = db.Column(db.Integer, default=30)
    
    # Status
    status = db.Column(db.String(20), default="scheduled")  # scheduled, completed, cancelled, no-show
    notes = db.Column(db.Text, nullable=True)
    reminder_sent = db.Column(db.Boolean, default=False)
    
    # Tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('appointments', lazy=True, cascade="all, delete-orphan"))
    prediction = db.relationship('Prediction', backref=db.backref('appointments', lazy=True))

    def __repr__(self):
        return f"<Appointment {self.doctor_name} - {self.appointment_date}>"
