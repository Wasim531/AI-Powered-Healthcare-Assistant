# 🚀 Quick Setup Guide - Doctor & Follow-up Features

## Prerequisites
- Python 3.8+
- All packages from `requirements.txt` installed

## 🔧 Installation Steps

### 1️⃣ **Backup Your Database (Optional but Recommended)**
```
Copy instance/healthcare.db to a safe location
```

### 2️⃣ **Run Database Migration**
Navigate to project directory and run:
```bash
python migrate_db.py
```

Expected output:
```
Adding 'selected_doctor' column...
✓ Added 'selected_doctor' column
Adding 'follow_up_days' column...
✓ Added 'follow_up_days' column

✓ Database migration completed successfully!
```

### 3️⃣ **Start the Application**

**Option A - Using batch file (Windows)**:
```bash
run_app.bat
```

**Option B - Direct Python**:
```bash
python app.py
```

The app will start at `http://localhost:5000`

### 4️⃣ **Verify Installation**

1. Open browser to http://localhost:5000
2. Log in with your account
3. Click "Analyze Symptoms Now"
4. Enter symptoms and submit
5. On result page, verify:
   - ✅ Doctor selection panel visible
   - ✅ Follow-up schedule inputs available
   - ✅ New "Follow-up Care" tab present
6. Go to Dashboard
7. Verify:
   - ✅ New "Doctor Selected" column in table

---

## 📋 What's New - Quick Overview

### Result Page Changes
```
OLD: Shows disease, probability, prescription, diet, remedies
NEW: ↓ + Doctor Selection Panel + Follow-up Schedule + New Tab
```

### New Components
- 🏥 **Doctor Selection**: Choose your preferred specialist
- 📅 **Follow-up Schedule**: Set reminder days (1-30)
- 📋 **Follow-up Care Tab**: Immediate actions + reminder tips
- 👨‍⚕️ **Home Page**: Enhanced doctor directory with all 11 specialists

### Dashboard Changes
```
OLD TABLE: Date | Symptoms | Disease | Certainty | Actions
NEW TABLE: Date | Symptoms | Disease | Doctor Selected | Certainty | Actions
```

---

## 🎯 Using the New Features

### Select a Doctor
1. Navigate to any prediction result
2. Scroll to "Select Your Preferred Doctor" section
3. A radio button will be pre-selected with the recommended doctor
4. Modify follow-up days if needed (default: 7)
5. Click **"Confirm Doctor Selection"**
6. You'll see a success message

### View Follow-up Instructions
1. On result page, click the **"Follow-up Care"** tab
2. See two sections:
   - **Immediate Actions**: What to do right now
   - **Follow-up Reminder**: When and why to visit doctor again

### Check Dashboard
1. Go to Dashboard
2. Look at the **"Doctor Selected"** column
3. See which doctors were selected for each prediction
4. Predictions without selection show "Not selected"

### Explore Doctor Directory (Home Page)
1. Scroll to **"Clinical Specialist Directory"** section
2. See all 11 specialist doctors
3. Each card shows:
   - Doctor icon and name
   - Specialty type
   - Associated diseases/conditions
   - Hover effect animation

---

## 🔗 API Reference

### Save Doctor Selection
**Endpoint**: `POST /api/update-doctor-selection/<prediction_id>`

**Headers**:
```
Content-Type: application/json
```

**Request Body**:
```json
{
  "doctor": "Dr. Name, MD",
  "follow_up_days": 7
}
```

**Response** (Success):
```json
{
  "success": true,
  "message": "Doctor selection saved successfully"
}
```

**Response** (Unauthorized):
```json
{
  "success": false,
  "error": "Unauthorized"
}
```

---

## 📊 Database Schema

### New Columns in `predictions` table:
| Column | Type | Default | Purpose |
|--------|------|---------|---------|
| `selected_doctor` | VARCHAR(150) | NULL | Doctor specialist name |
| `follow_up_days` | INTEGER | 7 | Days until follow-up visit |

---

## 🐛 Common Issues & Solutions

### Issue: "ModuleNotFoundError: No module named 'flask'"
**Solution**: Install requirements
```bash
pip install -r requirements.txt
```

### Issue: Database locked error
**Solution**: 
1. Close all instances of the app
2. Wait 5 seconds
3. Run migration again

### Issue: Migration script not found
**Solution**: Ensure you're in the project root directory
```bash
cd "c:\Users\HP\Desktop\Wasim khan AI project"
python migrate_db.py
```

### Issue: Doctor selection button disabled after first click
**This is intentional** - Button disables after saving to prevent duplicate submissions

### Issue: Follow-up tab shows "0 days"
**Solution**: The display number is separate from the input. Change input value and confirm selection again.

---

## 📞 Support

If you encounter issues:
1. Check the browser console for JavaScript errors (F12)
2. Check Flask console for Python errors
3. Verify database migration completed
4. Ensure you're logged in
5. Clear browser cache and try again

---

## ✅ Rollback (If Needed)

If you need to revert changes:
1. Restore your backup of `healthcare.db`
2. Restore original files from your version control
3. Restart the app

---

## 🎉 You're All Set!

Your AuraHealth AI now has:
✅ Doctor specialist recommendations  
✅ Follow-up reminder system  
✅ Enhanced patient guidance  
✅ Professional doctor directory  
✅ Comprehensive dashboard tracking  

Enjoy! 🏥

